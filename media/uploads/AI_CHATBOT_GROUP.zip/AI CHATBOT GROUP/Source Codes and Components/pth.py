import torch

# Load the contents of the .pth file into a Python variable
loaded_data = torch.load('data.pth')

# Print or inspect the loaded_data variable
print(loaded_data)
